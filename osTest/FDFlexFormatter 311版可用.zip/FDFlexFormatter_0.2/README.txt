[ FDFlexFormatter ]

[ Version ]
0.1

[ Author ]
Frederico Garcia

[ Description ]
MXML and AS3 coder formatter for FlashDevelop 3. Port of FlexFormatter by Ernest Pasour.

[ Installation]
Copy FDFlexFormatter.dll, Antlr3.Runtime.dll, Antlr3.Utility.dll into the plugins folder of your FD Application Files

[ Usage ]
Press Ctrl-Shift-F while editing an AS3, MXML or XML file to format code


[ CHANGE LOG ]

03.08.2009: Fixed "goto previous cursor position".
02.08.2009: Removed the "goto previous cursor position". Was too slow when there was lots of text. (like big comments).